Hi! u/Leafygoodnis here. Glad you took a look at this.

Inside you'll find a number of resources to help you run the Hope's Last Day scenario. Each character has their own pre-filled character sheet, Agenda sheet, and should be given a copy of both the Skill Roll Quick Reference and the scenario map. The 'Binder Back' document is useful if you have an actual binder with tabs to put the sections in, but it's also got some more quick reference to tables found in the Core Book.

Essentially, the players shouldn't need to have the actual book in their hands, as all the info pertinent to them has been printed and given to them from these materials. This way, the GM can have the book in their own hands at all times and will be able to quickly glance at Xeno stats, scenario details, and stuff like that. Multiple copies of this game's core book, especially now (at the time of release) are unlikely to be at the table, so it's good to have as much spread out like this as possible.

Other resources here include a blank version of the character sheet - Free League provides one on their site, but I made this one to be a slight improvement on that design. It features a bit cleaner of a layout, especially regarding the Skills section, and lets you track things like Reloads on your weapons a bit more easily. 

I also have weapon cards (in case you don't want to bog down the game with time spent reading out stats) and combat initiative cards in this package, as those only came with the Starter kit and even then the Weapon cards apparently have a number of errors printed on them. The initiative cards have an intuitive mechanic for tracking actions used outside of turn order, as well - just cover up a corner of your initiative card using your character sheet, depending on which action you performed. This makes actions like Blocking and Overwatch more intuitive for everybody involved.

Finally, you have a couple of my own custom GM tools - enemy reference cards for all the enemies that show up in the Hope's Last Day scenario, and not one but TWO GM screen designs. The first is a really general GM screen, much like the one provided in the Starter Kit. The second is specialized to Hope's Last Day, and gives you some of the scenario information that you would otherwise have to flip through the book for (and nobody wants that!)

Enjoy, and the best of luck to you!